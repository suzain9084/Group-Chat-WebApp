import { useState,useEffect } from 'react'
import ChatArea from './components/ChatArea'
import './App.css'

function App() {
  return (
    <>
      <ChatArea/>
    </>
  )
}

export default App
