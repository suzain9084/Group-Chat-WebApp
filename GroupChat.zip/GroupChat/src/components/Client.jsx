import React from 'react'
import './Client.css'

const Client = ({name}) => {
  return (
    <div className='client'>
        <img src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png" alt="" />
        <p>{name}</p>
    </div>
  )
}

export default Client