import React from 'react';
import './Message.css'

const Message = ({ detail }) => {
  return (
   
      <p className={detail.position}>{`${detail.name}: ${detail.message}`}</p>
  );
}

export default Message;
