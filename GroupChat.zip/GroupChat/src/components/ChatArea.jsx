import React, { useState, useEffect, useRef } from 'react';
import './ChatArea.css';
import send from './send.svg';
import io from 'socket.io-client';
import Message from './Message';
import Client from './Client';
import members from './members.svg';

const socket = io('http://localhost:3000');

const ChatArea = () => {
    const [message, setMessage] = useState('');
    const [chat, setChat] = useState([]);
    const [users, setUsers] = useState([]);
    const [show, setShow] = useState(false);
    const sendAudio = useRef(new Audio('./send.mp3'));
    const receiveAudio = useRef(new Audio('./receive.mp3'));

    useEffect(() => {
        const fetchClients = async () => {
            const name = prompt("Enter your Name");
            if (name) {
                socket.emit('new-user-joined', name);
                let res = await fetch('http://localhost:3000');
                let clients = await res.json();
                setUsers(clients.map(client => client.name));
                setUsers((prevUsers) => [...prevUsers, name]);
                await fetch(`http://localhost:3000/insert?name=${name}`)
            }

        };

        fetchClients();

        socket.on('user-joined', (data) => {
            setChat((prevChat) => [...prevChat, { message: `${data} has joined the Chat`, position: 'center', name: data }]);
            setUsers((prevUsers) => [...prevUsers, data]);
        });

        socket.on('receive', (data) => {
            setChat((prevChat) => [...prevChat, { message: data.message, position: 'left', name: data.name }]);
            receiveAudio.current.play();
        });

        socket.on('user-left',async (data) => {
            setChat((prevChat) => [...prevChat, { message: `${data} has left the Chat`, position: 'center', name: data }]);
            await fetch(`http://localhost:3000/left?name=${data}`)
            setUsers((prevUsers) => prevUsers.filter(user => user !== data));
        });

        return () => {
            socket.off('user-joined');
            socket.off('receive');
            socket.off('user-left');
        };
    }, []);

    const handleChange = (e) => {
        setMessage(e.target.value);
    };

    const sendMessage = () => {
        if (message.trim() !== '') {
            setChat((prevChat) => [...prevChat, { message, position: 'right', name: 'You' }]);
            socket.emit('send', message);
            sendAudio.current.play();
            setMessage('');
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    };

    const handleList = () => {
        setShow(!show);
    };

    return (
        <div className='chat-area'>
            <div className='chatHead'>
                <p>Chat</p>
                <img src={members} alt="Members" onClick={handleList} />
            </div>
            <div className='space'>
                {chat.map((detail, index) => (
                    <Message key={index} detail={detail} />
                ))}
            </div>
            <div className='controller'>
                <input
                    type="text"
                    placeholder='Type a message'
                    value={message}
                    onChange={handleChange}
                    onKeyDown={handleKeyPress}
                />
                <div><img src={send} alt="Send" onClick={sendMessage} /></div>
            </div>

            <div className={show ? 'clients' : 'none'}>
                <h3>Online Clients</h3>
                {users.map((name, index) => (
                    <Client key={index} name={name} />
                ))}
            </div>
        </div>
    );
};

export default ChatArea;