import mongoose from 'mongoose';
const { Schema } = mongoose;

const ClientSchema = new Schema({
  name: String
});

export const client = mongoose.model('Blog', ClientSchema);