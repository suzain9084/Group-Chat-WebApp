import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import mongoose from 'mongoose';
import { client } from './modules/clients.js';
import bodyParser from 'body-parser';

const app = express();

const corsOptions = {
    origin: 'http://localhost:5173',
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type'],
    credentials: true
};

mongoose.connect('mongodb://localhost:27017/ChatApp');

app.use(cors(corsOptions));
app.use(bodyParser.json());

const server = createServer(app);

const io = new Server(server, {
    cors: {
        origin: 'http://localhost:5173',
        methods: ['GET', 'POST'],
        allowedHeaders: ['Content-Type'],
        credentials: true
    }
});

app.get('/insert', async (req, res) => {
    await client.insertMany({ name: req.query.name });
    res.send('done');
});

app.get('/', async (req, res) => {
    const clients = await client.find({});
    res.send(clients);
});

app.get('/left', async (req, res) => {
    await client.deleteOne({name:req.query.name})
    res.send('done')
});

const users = {};

io.on('connection', (socket) =>{
    
    socket.on('new-user-joined', (name) => {
        users[socket.id] = name;
        socket.broadcast.emit('user-joined', name);
    });

    socket.on('send', (message) => {
        const name = users[socket.id];
        socket.broadcast.emit('receive', { message, name });
    });

    socket.on('disconnect', () => {
        const name = users[socket.id];
        if (name) {
            socket.broadcast.emit('user-left', name);
            delete users[socket.id];
        }
    });
});

server.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
